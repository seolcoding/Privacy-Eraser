using System.Runtime.InteropServices;

[assembly: System.Windows.ThemeInfo(System.Windows.ResourceDictionaryLocation.None, System.Windows.ResourceDictionaryLocation.SourceAssembly)]
[assembly: ComVisible(false)]
[assembly: Guid("ec827a36-8882-4b4f-a423-8c1983e28de3")]