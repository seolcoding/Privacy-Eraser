﻿namespace Scover.WinClean.View.Windows;

public sealed partial class ScriptExecutionWizard
{
    public ScriptExecutionWizard() => InitializeComponent();
}