# 07_API_SPECIFICATION

- Local module APIs for cleaning operations and scheduling controls


