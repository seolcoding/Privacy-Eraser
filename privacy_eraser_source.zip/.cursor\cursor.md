Always use uv for package manager and runner
use uv add instead of pip install

Always use uv run uv add for python package, running management