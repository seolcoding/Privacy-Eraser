﻿namespace Scover.WinClean.View.Windows;

public sealed partial class MainWindow
{
    public MainWindow() => InitializeComponent();
}