﻿namespace Scover.WinClean.View.Pages;

public sealed partial class Page2
{
    public Page2() => InitializeComponent();
}