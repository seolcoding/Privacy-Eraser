# 04_AUTO_UPDATE

- Source: GitHub Releases
- Background download, SHA256 verify, silent install support


