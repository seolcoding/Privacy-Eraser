# 06_DATABASE_SCHEMA

- SQLite: settings, schedules, logs, stats


