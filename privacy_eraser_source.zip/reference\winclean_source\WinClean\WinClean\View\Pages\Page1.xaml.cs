﻿namespace Scover.WinClean.View.Pages;

public sealed partial class Page1
{
    public Page1() => InitializeComponent();
}