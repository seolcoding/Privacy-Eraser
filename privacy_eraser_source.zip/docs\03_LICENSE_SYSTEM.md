# 03_LICENSE_SYSTEM

- Tiering: Free, Public (Busan), Education, Commercial, Enterprise
- Data: email, device hash, app version, license type
- Not collected: browsing data, history contents


