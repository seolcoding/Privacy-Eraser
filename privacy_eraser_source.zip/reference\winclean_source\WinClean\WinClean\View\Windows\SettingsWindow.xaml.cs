﻿namespace Scover.WinClean.View.Windows;

public sealed partial class SettingsWindow
{
    public SettingsWindow() => InitializeComponent();
}