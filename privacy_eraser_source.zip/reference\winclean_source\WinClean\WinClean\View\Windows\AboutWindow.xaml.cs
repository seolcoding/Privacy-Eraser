﻿namespace Scover.WinClean.View.Windows;

public sealed partial class AboutWindow
{
    public AboutWindow() => InitializeComponent();
}