﻿namespace Scover.WinClean.View.Pages;

public sealed partial class Page3
{
    public Page3() => InitializeComponent();
}