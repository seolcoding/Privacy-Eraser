﻿namespace Scover.WinClean.View.Controls;

public sealed partial class ExecutionInfoListView
{
    public ExecutionInfoListView() => InitializeComponent();
}