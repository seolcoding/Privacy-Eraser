# 08_DEPLOYMENT_GUIDE

- Packaging: PyInstaller, Inno Setup, code signing, GitHub Actions


